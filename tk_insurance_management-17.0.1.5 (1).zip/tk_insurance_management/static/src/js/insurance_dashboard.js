/** @odoo-module **/
import {registry} from "@web/core/registry";
import {Layout} from "@web/search/layout";
import {getDefaultConfig} from "@web/views/view";
import {useService} from "@web/core/utils/hooks";
import { useDebounced } from "@web/core/utils/timing";
import { session } from "@web/session";
import {Domain} from "@web/core/domain";
import {sprintf} from "@web/core/utils/strings";

const {Component, useSubEnv, useState, onMounted, onWillStart, useRef} = owl;
import {loadJS, loadCSS} from "@web/core/assets"

class InsuranceDashboard extends Component {
    setup() {
        this.rpc = useService("rpc");
        this.action = useService("action");
        this.orm = useService("orm");

        this.state = useState({
            totalInsurances : {'total_insurance': 0, 'running_insurance': 0, 'expired_insurance': 0},
            totalClaims : {'total_claim': 0, 'submit_claim': 0, 'approved_claim': 0, 'not_approved_claim': 0},
            insuranceAgents : {'res_partner_agent': 0},
            insuranceCategory: {'insurance_category': 0},
            totalClaimCount: {'x-axis': [], 'y-axis': []},
            insuranceStates: {'x-axis': [], 'y-axis': []},
            topAgents: {'x-axis': [], 'y-axis': []},
            genderCounts: {'x-axis': [], 'y-axis': []},
        });

        useSubEnv({
            config: {
                ...getDefaultConfig(),
                ...this.env.config,
            },
        });

        this.totalClaimCount = useRef('claim_approve_not_approve');
        this.insuranceStates = useRef('insurance_state');
        this.topAgents = useRef('insurance_top_agent');
        this.genderCounts = useRef('customer_gender');

        onWillStart( async () => {
            await loadJS('/tk_insurance_management/static/src/js/lib/apexcharts.js');
            let insuranceData = await this.orm.call('insurance.dashboard', 'get_insurance_dashboard', []);
            if(insuranceData){
                this.state.totalInsurances = insuranceData;
                this.state.totalClaims = insuranceData;
                this.state.insuranceAgents = insuranceData;
                this.state.insuranceCategory = insuranceData;
                this.state.totalClaimCount = {'x-axis': insuranceData['total_claim_count_graph'][0], 'y-axis': insuranceData['total_claim_count_graph'][1]}
                this.state.insuranceStates = {'x-axis': insuranceData['insurance_state_graph'][0], 'y-axis': insuranceData['insurance_state_graph'][1]}
                this.state.topAgents = {'x-axis': insuranceData['top_agents'][0], 'y-axis': insuranceData['top_agents'][1]}
                this.state.genderCounts = {'x-axis': insuranceData['gender_count'][0], 'y-axis': insuranceData['gender_count'][1]}
            }
        });
        onMounted(() => {
            this.renderTotalClaimCountGraph();
            this.renderInsuranceStateGraph();
            this.renderTopFiveAgentsGraph();
            this.renderGenderCountsGraph();
        })
    }

    viewInsurances(type){
        let domain,context;
        let name = this.getInsuranceStatus(type);
        if (type === 'all'){
            domain = []
        }else {
            domain = [['state', '=', type]]
        }
        context = { 'create':false }
        this.action.doAction({
            type: 'ir.actions.act_window',
            name: name,
            res_model: 'insurance.information',
            view_mode: 'kanban',
            views: [[false, 'list'], [false, 'form']],
            target: 'current',
            context: context,
            domain: domain,
        });
    }
    getInsuranceStatus(type){
        let name;
        if(type === 'all'){
            name = 'Total Insurances'
        }else if(type === 'running') {
            name = 'Running Insurances'
        } else if(type === 'expired') {
            name = 'Expired Insurances'
        }
        return name;
    }

    viewClaims(type){
        let domain,context;
        let name = this.getClaimStatus(type);
        if (type === 'all'){
            domain = []
        }else {
            domain = [['state', '=', type]]
        }
        context = { 'create':false }
        this.action.doAction({
            type: 'ir.actions.act_window',
            name: name,
            res_model: 'claim.information',
            view_mode: 'kanban',
            views: [[false, 'list'], [false, 'form']],
            target: 'current',
            context: context,
            domain: domain,
        });
    }
    getClaimStatus(type){
        let name;
        if(type === 'all'){
            name = 'Total Claims'
        }else if(type === 'submit') {
            name = 'Submit Claims'
        } else if(type === 'approved') {
            name = 'Approved Claims'
        }else if(type === 'not_approved') {
            name = 'Not Approved Claims'
        }
        return name;
    }

    viewInsuranceAgents(){
        let domain = [['is_agent', '=', true]];
        let context = { 'create':false }
        this.action.doAction({
            type: 'ir.actions.act_window',
            name: 'Agents',
            res_model: 'res.partner',
            domain: domain,
            view_mode: 'kanban',
            views: [[false, 'kanban'], [false, 'list'], [false, 'form']],
            target: 'current',
            context: context,
        });
    }

    viewInsuranceCategory (){
        let context = { 'create':false }
        this.action.doAction({
            type: 'ir.actions.act_window',
            name: 'Insurance Category',
            res_model: 'insurance.category',
            view_mode: 'kanban',
            views: [[false, 'list'], [false, 'form']],
            target: 'current',
            context: context,
        });
    }

    renderGraph(el, options){
        const graphData = new ApexCharts(el, options);
        graphData.render();
    }

    renderTotalClaimCountGraph(){
        const options = {
            series: [{
                name: 'Claim',
                data: this.state.totalClaimCount['y-axis'],
                }],
            chart: {
                height: 400,
                type: 'bar',
                events: {
                    click: function(chart, w, e) {}
                }
            },
            colors: ['#460C68', '#748E63', '#B04759'],
            plotOptions: {
                bar: {
                    columnWidth: '10%',
                    distributed: true,
                }
            },
            dataLabels: {
                enabled: false
            },
            legend: {
                show: false
            },
            xaxis: {
                categories: this.state.totalClaimCount['x-axis'],
                labels: {
                    style: {
                        colors: ['#460C68', '#CB1C8D', '#395144'],
                        fontSize: '12px'}
                }
            }
        };
        this.renderGraph(this.totalClaimCount.el, options);
    }

    renderInsuranceStateGraph(){
        const options = {
            series: [{
                name: 'Insurance',
                data: this.state.insuranceStates['y-axis'],
            }],
            chart: {
                height: 400,
                type: 'bar',
                events: {
                    click: function(chart, w, e) {}
                }
            },
            colors: ['#EBE76C', '#557C55'],
            plotOptions: {
                bar: {
                    columnWidth: '10%',
                    distributed: true,
                }
            },
            dataLabels: {
                enabled: false
            },
            legend: {
                show: false
            },
            xaxis: {
                categories: this.state.insuranceStates['x-axis'],
                labels: {
                    style: {
                        colors: ['#FF6464', '#000000'],
                        fontSize: '12px'
                    }
                }
            }
        };
        this.renderGraph(this.insuranceStates.el, options);
    }

    renderTopFiveAgentsGraph(){
        const options = {
            series: this.state.topAgents['y-axis'],
            chart: {
                type: 'donut',
                height: 410
            },
            colors: ['#ADA2FF', '#E0144C', '#D6E4E5', '#F49D1A'],
            dataLabels: {
                enabled: false
            },
            labels: this.state.topAgents['x-axis'],
            legend: {
                position: 'bottom',
            },
        };
        this.renderGraph(this.topAgents.el, options);
    }
    renderGenderCountsGraph() {
        const options = {
            series: this.state.genderCounts['y-axis'],
            chart: {
                width: 500,
                height: 500,
                type: 'pie',
            },
            labels: this.state.genderCounts['x-axis'],
            responsive: [{
                breakpoint: 480,
                options: {
                    chart: {
                        width: 200
                    },
                    legend: {
                        position: 'bottom'
                    }
                }
            }]
        };
        this.renderGraph(this.genderCounts.el, options);
    }
}
InsuranceDashboard.template = "tk_insurance_management.ins_dashboard";
registry.category("actions").add("insurance_dashboard", InsuranceDashboard);