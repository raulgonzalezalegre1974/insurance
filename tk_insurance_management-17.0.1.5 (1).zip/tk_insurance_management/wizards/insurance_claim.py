# -*- coding: utf-8 -*-
# Copyright 2022-Today TechKhedut.
# Part of TechKhedut. See LICENSE file for full copyright and licensing details.
from odoo import fields, api, models, _
from odoo.exceptions import ValidationError


class InsuranceClaim(models.TransientModel):
    """Insurance Claim"""
    _name = 'insurance.claim'
    _description = __doc__

    insurance_id = fields.Many2one('insurance.information', string="Insurance", required=True)
    claim_date = fields.Date(string='Date')

    @api.model
    def default_get(self, field):
        res = super(InsuranceClaim, self).default_get(field)
        res['insurance_id'] = self._context.get('active_id')
        return res

    @api.constrains('claim_date', 'insurance_id')
    def _check_claim_date(self):
        for rec in self:
            if rec.claim_date and rec.insurance_id:
                if rec.claim_date < rec.insurance_id.issue_date or rec.claim_date > rec.insurance_id.expiry_date:
                    raise ValidationError(_("Claim Date must be within the insurance coverage period!"))

    def insurance_claim_create(self):
        for rec in self.insurance_id:
            if rec.total_due_amount <= 0.0:
                message = {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'type': 'warning',
                        'message': "You are not eligible to create additional claims.",
                        'sticky': False,
                    }
                }
                return message
            data = {
                'insurance_id': rec.id,
                'claim_date': self.claim_date,
                'insured_id': rec.insured_id.id,
                'dob': rec.dob,
                'age': rec.age,
                'phone': rec.insured_id.phone,
                'insurance_nominee_id': rec.insurance_nominee_id.id,
                'insurance_nominee_relation_id': rec.insurance_nominee_relation_id.id,
                'nominee_dob': rec.nominee_dob,
                'insurance_policy_id': rec.insurance_policy_id.id,
                'insurance_category_id': rec.insurance_category_id.id,
                'insurance_sub_category_id': rec.insurance_sub_category_id.id,
                'agent_id': rec.agent_id.id,
                'insurance_time_period': rec.insurance_time_period,
                'policy_amount': rec.total_policy_amount,
                'due_amount': rec.total_due_amount,
            }
            claim = self.env['claim.information'].create(data)
            return {
                'type': 'ir.actions.act_window',
                'name': _('Claim'),
                'res_model': 'claim.information',
                'res_id': claim.id,
                'view_mode': 'form',
                'target': 'current'
            }
