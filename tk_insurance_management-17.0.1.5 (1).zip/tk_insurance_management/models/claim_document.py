# -*- coding: utf-8 -*-
# Copyright 2022-Today TechKhedut.
# Part of TechKhedut. See LICENSE file for full copyright and licensing details.
from odoo import models, fields, api


class ClaimDocuments(models.Model):
    """Claim Documents"""
    _name = 'claim.documents'
    _description = __doc__
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'claim_document_type_id'

    claim_document_type_id = fields.Many2one('claim.document.type', string="Document Type", required=True)
    file_name = fields.Char(string="File Name", translate=True)
    description = fields.Char(string="Description", translate=True)
    state = fields.Selection([('draft', "Draft"), ('verified', "Verified"), ('rejected', "Rejected")], string="Status",
                             default='draft')
    avatar = fields.Binary(string="Document")
    claim_information_id = fields.Many2one('claim.information')

    def document_resubmit(self):
        self.state = 'draft'

    def verified_claim(self):
        self.state = 'verified'

    def rejected_claim(self):
        self.state = 'rejected'
