# -*- coding: utf-8 -*-
# Copyright 2022-Today TechKhedut.
# Part of TechKhedut. See LICENSE file for full copyright and licensing details.
from dateutil.relativedelta import relativedelta
from datetime import datetime
from odoo.exceptions import ValidationError
from odoo import api, fields, models, _


class InsuranceInformation(models.Model):
    """Insurance Information"""
    _name = 'insurance.information'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = __doc__
    _rec_name = 'insurance_number'

    insurance_number = fields.Char(string='Insurance', required=True, readonly=True, default=lambda self: _('New'),
                                   copy=False)
    insured_id = fields.Many2one('res.partner', string='Insured', required=True, domain="[('is_agent', '=', False)]")
    insurance_nominee_id = fields.Many2one('insurance.nominee', string="Nominee")
    insurance_nominee_relation_id = fields.Many2one('insurance.nominee.relation', string="Your Nominee is Your")
    nominee_dob = fields.Date(string="Date of Birth")

    dob = fields.Date(string="Date Of Birth", required=True)
    age = fields.Char(string="Age", compute="get_insured_age_count", translate=True)
    gender = fields.Selection([('male', "Male"), ('female', "Female"), ('others', "Others")], string="Gender",
                              required=True)
    issue_date = fields.Date(string="Issue Date", required=True)
    expiry_date = fields.Date(string="Expiry Date", readonly=True, compute="_compute_time_period_date")
    agent_id = fields.Many2one('res.partner', string='Agent', domain=[('is_agent', '=', True)])
    agent_phone = fields.Char(related='agent_id.phone', string="Phone", translate=True)

    premium_type = fields.Selection([('fixed', "Fixed"), ('installment', "Installment")], default='fixed',
                                    string="Premium Type")
    insurance_category_id = fields.Many2one('insurance.category', string="Policy Category", required=True)
    category = fields.Selection(related="insurance_category_id.category")
    insurance_sub_category_id = fields.Many2one('insurance.sub.category', string="Sub Category",
                                                domain="[('insurance_category_id', '=', insurance_category_id)]",
                                                required=True)
    insurance_policy_id = fields.Many2one('insurance.policy', string='Insurance Policy',
                                          domain="[('insurance_sub_category_id', '=', insurance_sub_category_id)]",
                                          required=True)

    insurance_buying_for_id = fields.Many2one('insurance.buying.for', string="Buying For",
                                              domain="[('insurance_category_id', '=', insurance_category_id)]")
    insurance_time_period = fields.Char(related="insurance_policy_id.insurance_time_period_id.t_period", translate=True,
                                        string="Policy Time Period")
    duration = fields.Integer(related="insurance_policy_id.insurance_time_period_id.duration",
                              string="Duration (Months)")
    policy_terms_and_conditions = fields.Text(string="Terms & Conditions", translate=True)

    policy_amount = fields.Monetary(string="Policy Amount")
    commission_type = fields.Selection([('fixed', "Fixed"), ('percentage', "Percentage")],
                                       string="Commission Type")
    fixed_commission = fields.Monetary(string="Fixed Amount")
    percentage_commission = fields.Float(string="Commission")
    total_commission = fields.Monetary(string="Total", compute="total_agent_commission")
    total_policy_amount = fields.Monetary(string="Total Policy Amount", compute="_compute_total_policy_amount")

    duration = fields.Integer(related="insurance_policy_id.duration", string="Duration (Months)")
    monthly_installment = fields.Monetary(string="Monthly Installment", required=True)
    company_id = fields.Many2one('res.company', default=lambda self: self.env.company, string="Company")
    currency_id = fields.Many2one('res.currency', string='Currency', related="company_id.currency_id")

    invoice_id = fields.Many2one('account.move')
    payment_state = fields.Selection(related="invoice_id.payment_state", string="Invoice Status")
    agent_bill_id = fields.Many2one('account.move', string="Commission Bill")

    insurance_emi_ids = fields.One2many('insurance.emi', 'insurance_information_id')
    state = fields.Selection([('draft', "New"), ('running', "Running"), ('expired', "Expired")], default='draft',
                             string="Status", group_expand='_expand_groups')
    instalment_complete = fields.Boolean()

    insured_document_ids = fields.One2many("insured.documents", 'insured_info_id', string="Document")

    document_count = fields.Integer(compute='_compute_document_count')
    claim_count = fields.Integer(compute='_compute_claim_count')

    # Life Insurance:
    life_insured_age = fields.Selection(
        [('five_to_twenty', "Between 5 to 20 Years"), ('twenty_to_fifty', "Between 20 to 50 Years"),
         ('fifty_to_seventy', "Between 50 to 70 Years"), ('above_seventy', "Above 70 Years"),
         ('below_five', "Invalid age")], string=" Insured Age")
    desired_death_amount = fields.Monetary(string="Death Amount")
    life_deductible_amount = fields.Monetary()
    is_smoking_status = fields.Selection([('yes', "Yes"), ('no', "No")], string="Smoking Status")
    length_of_coverage_term = fields.Text(string="Length of Coverage Terms", translate=True)
    life_health_history = fields.Text(string="Insured Health History", translate=True)
    occupation_and_hobbies = fields.Text(string="Occupation and Hobbies Insured", translate=True)
    family_medical_history = fields.Text(string="Family Medical History", translate=True)

    # Health Insurance:
    health_insured_age = fields.Selection(
        [('five_to_twenty', "Between 5 to 20 Years"), ('twenty_to_fifty', "Between 20 to 50 Years"),
         ('fifty_to_seventy', "Between 50 to 70 Years"), ('above_seventy', "Above 70 Years"),
         ('below_five', "Invalid age")], string="Insured Age")
    desired_coverage_type = fields.Selection([('individual', "Individual"), ('family', "Family"), ('group', "Group")])
    health_deductible_amount = fields.Monetary()
    copay_amount = fields.Monetary(string="Co-pay Amount")
    out_of_pocket_maximum = fields.Text(string="Out-of-Pocket Maximum", translate=True)
    health_history_of_insured = fields.Text(translate=True)
    drug_coverage = fields.Text(string="Prescription Drug Coverage", translate=True)
    healthcare_provider_network = fields.Text(string="Preferred Healthcare Provider Network", translate=True)

    # Property Insurance:
    construct_year = fields.Char(string="Construct Year", translate=True)
    street = fields.Char(string="Street", translate=True)
    street2 = fields.Char(string="Street 2", translate=True)
    city = fields.Char(string="City", translate=True)
    country_id = fields.Many2one("res.country", string="Country")
    state_id = fields.Many2one("res.country.state", string="State", domain="[('country_id', '=?', country_id)]")
    zip = fields.Char(string="Zip")
    property_value = fields.Monetary(string="Estimated Value")
    property_damage_coverage = fields.Monetary(string="Damage Coverage")
    property_deductible_amount = fields.Monetary()
    desired_coverage_types = fields.Selection(
        [('dwelling', "Dwelling"), ('personal_property', "Personal Property"), ('liability', "Liability"),
         ('additional_living_expenses', "Additional Living Expenses")])
    property_coverage_limits = fields.Text(string="Property Coverage Limits", translate=True)
    construction_type_and_materials = fields.Text(string="Construction Type and Materials", translate=True)
    special_features_of_the_property = fields.Text(string="Special Features of the Property", translate=True)
    personal_property_inventory = fields.Text(string="Personal Property Inventory", translate=True)

    # Liability Insurance:
    type_of_liability_risk = fields.Selection(
        [('auto', "Auto"), ('homeowner', "HomeOwner's"), ('business', "Business")], string="Liability Risk")
    liability_coverage_type = fields.Selection(
        [('general_liability', "General Liability"), ('professional_liability', "Professional Liability")],
        default='general_liability')
    desired_coverage_limits = fields.Text(string="Desired Coverage Limits", translate=True)
    business_type_and_operations = fields.Text(translate=True)

    # Disability Insurance:
    occupation = fields.Char(string="Occupation", translate=True)
    income = fields.Monetary(string="Income")
    disability_desired_benefit_amount = fields.Monetary(string="Desired Amount")
    insured_is_smoking = fields.Boolean(string="Insured is Smoking")
    length_coverage_disability_period = fields.Text(string="Length of Coverage Period", translate=True)
    disability_health_history = fields.Text(translate=True)
    occupation_and_hobbies = fields.Text(string="Occupation and Hobbies", translate=True)

    # Travel Insurance:
    types_of_coverage = fields.Selection(
        [('trip_cancellation', "Trip Cancellation"), ('medical_emergency', "Medical Emergency"),
         ('lost_luggage', "Lost Luggage")], string="Type of Coverage")
    trip_length = fields.Integer(string="Trip Length")
    trip_coverage_amount = fields.Monetary(string="Coverage Amount")
    odometer_unit = fields.Selection([('km', 'Kilometers'), ('mi', 'Miles')], 'Odometer Unit', default='km')
    traveler_health_history = fields.Text(string="Traveler Health History", translate=True)

    # Pet Insurance:
    age_of_breed_of_the_pet = fields.Integer(string="Age of Breed")
    pet_desired_coverage_type = fields.Selection(
        [('accident', "Accident"), ('illness', "Illness"), ('comprehensive', "Comprehensive")])
    exclusions = fields.Selection(
        [('pre_existing_conditions', "Pre-Existing Conditions"), ('certain_breeds', "Certain Breeds")],
        string="Exclusions")

    accident_coverage = fields.Monetary(string="Accident Amount")
    illness_coverage = fields.Monetary(string="Illness Amount")
    pet_deductible_amount = fields.Monetary()
    pet_coverage_limits = fields.Text(string="Coverage Limits", translate=True)

    # Business Insurance:
    business_desired_coverage_type = fields.Selection(
        [('property_damage', "Property Damage"), ('liability', "Liability"), ('workers', "Workers Compensation")])
    number_of_employees = fields.Integer(string="No. of Employees")
    business_property_value = fields.Monetary(string="Property Value")
    business_deductible_amount = fields.Monetary()
    business_type_operation = fields.Text(translate=True)
    business_coverage_limits = fields.Text(string="Business Coverage Limits", translate=True)
    industry_specific_risks = fields.Text(string=" Industry-Specific Risks", translate=True)

    # Vehicle Insurance:
    vehicle_name = fields.Char(string="Vehicle", translate=True)
    model = fields.Char(string="Model", translate=True)
    year = fields.Char(string="Year of MFG", translate=True)
    vin_no = fields.Char(string="VIN No", translate=True)
    reg_no = fields.Char(string="Registration No", translate=True)
    place_of_reg = fields.Char(string="Place of Registration", translate=True)
    cubic_capacity = fields.Integer(string="Cubic Capacity")
    setting_capacity = fields.Integer(string="Seating Capacity")
    usage_of_vehicle = fields.Selection([('personal', "Personal"), ('commercial', "Commercial")],
                                        string="Usage of Vehicle")
    coverage_type = fields.Selection([('liability', "Liability"), ('collision', "Collision"),
                                      ('comprehensive', "Comprehensive")])

    # Policy Details
    policy_certificate_no = fields.Char(string="Policy/Certificate No", translate=True)
    previous_policy_no = fields.Char(string="Previous Policy No", translate=True)

    # Vehicle IDV
    for_the_vehicle = fields.Monetary(string="For the Vehicle")
    for_trailer = fields.Monetary(string="For Trailer")
    non_electric_accessories = fields.Monetary(string="Non Electric Accessories")
    electric_accessories = fields.Monetary(string="Electric Accessories")
    value_of_cng_lpg_kit = fields.Monetary(string="Value of CNG/LPG Kit")
    total_idv = fields.Monetary(string="Total IDV Value")

    # Own Damage
    basic_od = fields.Monetary(string="Basic OD")
    od_package_premium = fields.Monetary()
    service_tax = fields.Monetary(string="Service Tax")
    special_discount = fields.Monetary(string="Special Discount (-)")
    final_premium = fields.Monetary(string="Final Premium")

    # Liability
    basic_tp_liability = fields.Monetary(string="Basic TP Liability")
    pa_cover_for_owner_driver = fields.Monetary(string="PA Cover for Owner-Driver")
    package_premium = fields.Monetary()
    liability_service_tax = fields.Monetary(string=" Service Tax")
    total_premium = fields.Monetary(string="Total Premium")

    limitation_as_to_use = fields.Text(string="Limitations as to Use", translate=True)
    limits_of_liability = fields.Text(string="Limits of Liability", translate=True)
    deductibles_under_section = fields.Text(string="Deductibles Under Section", translate=True)
    special_conditions = fields.Text(string="Special Conditions", translate=True)
    driving_history = fields.Text(string="Driving History of the Insured", translate=True)
    vehicle_insurance_image_ids = fields.One2many('vehicle.insurance.image', 'insurance_information_id',
                                                  string="Images")

    total_due_amount = fields.Monetary(string="Due Amount", compute="_get_insurance_due_amount")
    claim_amount = fields.Monetary(string="Claim Amount")

    # unused
    your_nominee_is_your = fields.Selection([('grand_daughter', "Grand Daughter"), ('grand_mother', "Grand Mother"),
                                             ('niece', "Niece"), ('sister', "Sister"), ('aunt', "Aunt"),
                                             ('daughter', "Daughter"), ('mother', "Mother")],
                                            string=" Your Nominee is Your")

    insured_document_id = fields.Many2one("insured.documents")

    @api.model
    def _expand_groups(self, states, domain, order):
        return ['draft', 'running', 'expired']

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('insurance_number', _('New')) == _('New'):
                vals['insurance_number'] = self.env['ir.sequence'].next_by_code('insurance.information') or _('New')
        res = super(InsuranceInformation, self).create(vals_list)
        return res

    @api.onchange('insurance_policy_id')
    def policy_terms_and_condition(self):
        for rec in self:
            if rec.insurance_policy_id:
                rec.policy_terms_and_conditions = rec.insurance_policy_id.policy_terms_and_conditions
            else:
                rec.policy_terms_and_conditions = False

    @api.onchange('insurance_category_id')
    def get_policy_category(self):
        for rec in self:
            if rec.insurance_category_id:
                rec.insurance_sub_category_id = False
                rec.insurance_policy_id = False
                rec.insurance_buying_for_id = False
                rec.policy_amount = False
                rec.insurance_time_period = False
                rec.issue_date = False
                rec.policy_terms_and_conditions = False

    @api.onchange('insurance_nominee_id')
    def insurance_nominee_details(self):
        for rec in self:
            if rec.insurance_nominee_id:
                rec.insurance_nominee_relation_id = rec.insurance_nominee_id.insurance_nominee_relation_id.id
                rec.nominee_dob = rec.insurance_nominee_id.nominee_dob
            else:
                rec.insurance_nominee_relation_id = False
                rec.nominee_dob = False

    @api.onchange('insurance_category_id')
    def get_insurance_category(self):
        for rec in self:
            if rec.insurance_category_id:
                # Life Insurance:
                rec.length_of_coverage_term = rec.insurance_category_id.length_of_coverage_term
                rec.life_health_history = rec.insurance_category_id.life_health_history
                rec.occupation_and_hobbies = rec.insurance_category_id.occupation_and_hobbies
                rec.family_medical_history = rec.insurance_category_id.family_medical_history
                # Health Insurance:
                rec.out_of_pocket_maximum = rec.insurance_category_id.out_of_pocket_maximum
                rec.health_history_of_insured = rec.insurance_category_id.health_history_of_insured
                rec.drug_coverage = rec.insurance_category_id.drug_coverage
                rec.healthcare_provider_network = rec.insurance_category_id.healthcare_provider_network
                # Property Insurance:
                rec.property_coverage_limits = rec.insurance_category_id.property_coverage_limits
                rec.construction_type_and_materials = rec.insurance_category_id.construction_type_and_materials
                rec.special_features_of_the_property = rec.insurance_category_id.special_features_of_the_property
                rec.personal_property_inventory = rec.insurance_category_id.personal_property_inventory
                # Liability Insurance:
                rec.desired_coverage_limits = rec.insurance_category_id.desired_coverage_limits
                rec.business_type_and_operations = rec.insurance_category_id.business_type_and_operations
                # Disability Insurance:
                rec.length_coverage_disability_period = rec.insurance_category_id.length_coverage_disability_period
                rec.disability_health_history = rec.insurance_category_id.disability_health_history
                rec.occupation_and_hobbies = rec.insurance_category_id.occupation_and_hobbies
                # Travel Insurance:
                rec.traveler_health_history = rec.insurance_category_id.traveler_health_history
                # Pet Insurance:
                rec.pet_coverage_limits = rec.insurance_category_id.pet_coverage_limits
                # Business Insurance:
                rec.business_type_operation = rec.insurance_category_id.business_type_operation
                rec.business_coverage_limits = rec.insurance_category_id.business_coverage_limits
                rec.industry_specific_risks = rec.insurance_category_id.industry_specific_risks
                # Vehicle Insurance:
                rec.driving_history = rec.insurance_category_id.driving_history
                rec.limitation_as_to_use = rec.insurance_category_id.limitation_as_to_use
                rec.limits_of_liability = rec.insurance_category_id.limits_of_liability
                rec.deductibles_under_section = rec.insurance_category_id.deductibles_under_section
                rec.special_conditions = rec.insurance_category_id.special_conditions

    @api.onchange('for_the_vehicle', 'for_trailer', 'non_electric_accessories', 'electric_accessories',
                  'value_of_cng_lpg_kit')
    def _vehicle_idv_value(self):
        for rec in self:
            rec.total_idv = (
                    rec.for_the_vehicle +
                    rec.for_trailer +
                    rec.non_electric_accessories +
                    rec.electric_accessories +
                    rec.value_of_cng_lpg_kit
            )

    @api.onchange('basic_od', 'od_package_premium', 'service_tax', 'special_discount')
    def _own_damage_value(self):
        for record in self:
            record.final_premium = (
                    record.basic_od +
                    record.od_package_premium +
                    record.service_tax -
                    record.special_discount
            )

    @api.onchange('basic_tp_liability', 'pa_cover_for_owner_driver', 'package_premium', 'liability_service_tax')
    def _liability_value(self):
        for value in self:
            value.total_premium = (
                    value.basic_tp_liability +
                    value.pa_cover_for_owner_driver +
                    value.package_premium +
                    value.liability_service_tax
            )

    @api.depends('dob')
    def get_insured_age_count(self):
        today = fields.Date.today()
        for rec in self:
            if rec.dob:
                if rec.dob > today:
                    raise ValidationError(_("DOB should be earlier than today's date."))
                age = today.year - rec.dob.year - ((today.month, today.day) < (rec.dob.month, rec.dob.day))
                rec.age = str(max(age, 0)) + ' Years'
            else:
                rec.age = str(0) + ' Years'

    @api.constrains('issue_date')
    def _check_issue_date(self):
        today = fields.Date.today()
        for record in self:
            if record.issue_date > today:
                raise ValidationError(_("Ensure Issue Date is not after today."))

    @api.constrains('nominee_dob')
    def _check_nominee_dob(self):
        today = fields.Date.today()
        for record in self:
            if record.nominee_dob:
                if record.nominee_dob > today:
                    raise ValidationError(_("Nominee's birthdate must precede today to proceed"))

    @api.constrains('is_smoking_status')
    def _is_smoking_status(self):
        for record in self:
            if record.insurance_category_id.category == 'life':
                if not record.is_smoking_status:
                    raise ValidationError(_("Select smoking status for safety information."))

    @api.constrains('types_of_coverage')
    def _types_of_coverage(self):
        for record in self:
            if record.insurance_category_id.category == 'travel':
                if not record.types_of_coverage:
                    raise ValidationError(_(
                        "Select coverage type: Trip Cancellation, Medical Emergency, or Lost Luggage for accurate details"))

    @api.constrains('pet_desired_coverage_type')
    def _pet_desired_coverage(self):
        for record in self:
            if record.insurance_category_id.category == 'pet':
                if not record.pet_desired_coverage_type:
                    raise ValidationError(_(
                        "Select coverage type: Accident, Illness, or Comprehensive for accurate details"))

    @api.constrains('business_desired_coverage_type')
    def _business_desired_coverage(self):
        for record in self:
            if record.insurance_category_id.category == 'business':
                if not record.business_desired_coverage_type:
                    raise ValidationError(_(
                        "Select coverage type: Property Damage, Liability, or Workers Compensation for accurate details"))

    @api.depends('total_due_amount')
    def _get_insurance_due_amount(self):
        for rec in self:
            claims = self.env['claim.information'].sudo().search([('insurance_id', 'in', rec.ids)])
            total_ins_amount = rec.claim_amount
            for claim in claims:
                if claim.policy_amount and claim.amount_paid:
                    total_ins_amount -= claim.amount_paid
            rec.total_due_amount = total_ins_amount

    def action_remaining_amount(self):
        return True

    @api.onchange('age')
    def _check_agg_status(self):
        for record in self:
            if record.age:
                age_numeric = int(''.join(filter(str.isdigit, record.age)))
                if 5 <= age_numeric < 20:
                    record.life_insured_age = 'five_to_twenty'
                    record.health_insured_age = 'five_to_twenty'
                elif 20 <= age_numeric < 50:
                    record.life_insured_age = 'twenty_to_fifty'
                    record.health_insured_age = 'twenty_to_fifty'
                elif 50 <= age_numeric < 70:
                    record.life_insured_age = 'fifty_to_seventy'
                    record.health_insured_age = 'fifty_to_seventy'
                elif age_numeric >= 70:
                    record.life_insured_age = 'above_seventy'
                    record.health_insured_age = 'above_seventy'
                else:
                    record.life_insured_age = 'below_five'
                    record.health_insured_age = 'below_five'
            else:
                record.life_insured_age = 'below_five'
                record.health_insured_age = 'below_five'

    def draft_to_running(self):
        self.state = 'running'

    @api.model
    def action_create_expired_policy(self):
        insurance = self.env['insurance.information'].sudo().search([])
        today_date = fields.Date.today()
        for data in insurance:
            for rec in data:
                if rec.expiry_date == today_date:
                    rec.running_to_expired()

    def running_to_expired(self):
        self.state = 'expired'
        mail_template = self.env.ref('tk_insurance_management.insurance_policy_has_expired_mail_template')
        if mail_template:
            ctx = {
                'default_model': self._name,
                'default_res_id': self.id,
            }
            mail_template.with_context(ctx).send_mail(self.id, force_send=True)

    def _compute_document_count(self):
        for rec in self:
            document_count = self.env['insured.documents'].search_count([('insured_info_id', '=', rec.id)])
            rec.document_count = document_count
        return True

    def action_insured_document(self):
        return {
            'type': 'ir.actions.act_window',
            'name': _('Documents'),
            'res_model': 'insured.documents',
            'domain': [('insured_info_id', '=', self.id)],
            'context': {'default_insured_info_id': self.id},
            'view_mode': 'tree',
            'target': 'current',
        }

    def _compute_claim_count(self):
        for rec in self:
            claim_count = self.env['claim.information'].search_count([('insurance_id', '=', rec.id)])
            rec.claim_count = claim_count
        return True

    def action_insured_claim(self):
        return {
            'type': 'ir.actions.act_window',
            'name': _('Claims'),
            'res_model': 'claim.information',
            'domain': [('insurance_id', '=', self.id)],
            'context': {
                'default_insurance_id': self.id,
                'create': False
            },
            'view_mode': 'tree,form',
            'target': 'current',
        }

    @api.depends('issue_date', 'duration')
    def _compute_time_period_date(self):
        for rec in self:
            expiry_date = fields.date.today()
            if rec.issue_date:
                expiry_date = rec.issue_date + relativedelta(months=rec.duration)
            rec.expiry_date = expiry_date

    @api.onchange('insurance_policy_id')
    def get_insurance_policy_amount(self):
        for rec in self:
            if rec.insurance_policy_id:
                rec.policy_amount = rec.insurance_policy_id.policy_amount

    @api.depends('commission_type', 'percentage_commission', 'policy_amount')
    def total_agent_commission(self):
        for rec in self:
            if rec.commission_type == "percentage":
                rec.total_commission = (rec.percentage_commission * rec.policy_amount) / 100
            else:
                rec.total_commission = 0.0

    @api.depends('total_policy_amount', 'commission_type', 'total_commission', 'policy_amount', 'fixed_commission')
    def _compute_total_policy_amount(self):
        for rec in self:
            if rec.commission_type == "percentage":
                rec.total_policy_amount = rec.policy_amount + rec.total_commission
            else:
                rec.total_policy_amount = rec.policy_amount + rec.fixed_commission

    @api.onchange('total_policy_amount', 'duration')
    def _total_monthly_installment_amount(self):
        for rec in self:
            if rec.duration > 0:
                rec.monthly_installment = rec.total_policy_amount / rec.duration

    @api.constrains('type_of_liability_risk')
    def _check_type_of_liability_risk(self):
        for record in self:
            if record.insurance_policy_id.category == "liability":
                if not record.type_of_liability_risk:
                    raise ValidationError(_(
                        "Select liability risk: Auto, Homeowner's, Business. Important decision."))

    def action_create_agent_bill(self):
        for rec in self:
            if not rec.insured_document_ids:
                message = {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'type': 'warning',
                        'message': "Add the required insurance document for record",
                        'sticky': False,
                    }
                }
                return message
            if any(record.state != 'verified' for record in rec.insured_document_ids):
                message = {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'type': 'warning',
                        'message': "Please verify insurance documents",
                        'sticky': False,
                    }
                }
                return message
            if not rec.commission_type:
                message = {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'type': 'warning',
                        'message': "Please first select the commission type.",
                        'sticky': False,
                    }
                }
                return message
            insurance = " ".join(ins.insurance_number for ins in rec)
            invoice_lines = []
            if rec.commission_type == 'fixed':
                if not rec.fixed_commission:
                    message = {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'type': 'warning',
                            'message': "Please add the required commission fixed value before proceeding!",
                            'sticky': False,
                        }
                    }
                    return message
                fixed_commission = {
                    'product_id': self.env.ref('tk_insurance_management.agent_commission_bill').id,
                    'name': insurance,
                    'quantity': 1,
                    'price_unit': rec.fixed_commission,
                }
                invoice_lines = [(0, 0, fixed_commission)]
            elif rec.commission_type == 'percentage':
                if not rec.total_commission:
                    message = {
                        'type': 'ir.actions.client',
                        'tag': 'display_notification',
                        'params': {
                            'type': 'warning',
                            'message': "Please add the required commission percentage value before proceeding!",
                            'sticky': False,
                        }
                    }
                    return message
                percentage_commission = {
                    'product_id': self.env.ref('tk_insurance_management.agent_commission_bill').id,
                    'name': insurance,
                    'quantity': 1,
                    'price_unit': rec.total_commission,
                }
                invoice_lines = [(0, 0, percentage_commission)]
            data = {
                'partner_id': rec.agent_id.id,
                'move_type': 'in_invoice',
                'invoice_date': fields.Date.today(),
                'invoice_line_ids': invoice_lines,
                'insurance_information_id': rec.id
            }
            agent_bill_id = self.env['account.move'].sudo().create(data)
            agent_bill_id.action_post()
            rec.agent_bill_id = agent_bill_id.id
            return {
                'type': 'ir.actions.act_window',
                'name': _('Commission Bill'),
                'res_model': 'account.move',
                'res_id': agent_bill_id.id,
                'view_mode': 'form',
                'target': 'current'
            }

    def action_create_emi_installment(self):
        today_date = fields.date.today()
        for rec in self:
            if not rec.claim_amount or rec.claim_amount <= 0:
                raise ValidationError(_("Claim amount must be greater than zero."))
            if rec.issue_date:
                for i in range(rec.insurance_policy_id.duration):
                    installment_date = rec.issue_date + relativedelta(months=i)
                    data = {
                        'insurance_information_id': rec.id,
                        'name': f'Installment {i + 1}',
                        'installment_date': installment_date,
                        'installment_amount': rec.monthly_installment,
                    }
                    self.env['insurance.emi'].create(data)
                rec.state = 'running'
        self.instalment_complete = True

    def action_insurance_invoice(self):
        for rec in self:
            if not rec.claim_amount:
                raise ValidationError(_("Claim amount must be greater than zero."))
        insurance_invoice = {
            'product_id': self.env.ref('tk_insurance_management.insurance_invoice').id,
            'name': self.insurance_policy_id.policy_name,
            'quantity': 1,
            'price_unit': self.total_policy_amount,
        }
        invoice_lines = [(0, 0, insurance_invoice)]
        data = {
            'partner_id': self.insured_id.id,
            'move_type': 'out_invoice',
            'invoice_date': fields.Date.today(),
            'invoice_line_ids': invoice_lines,
            'insurance_information_id': self.id,
        }
        invoice_id = self.env['account.move'].sudo().create(data)
        invoice_id.action_post()
        self.write({'invoice_id': invoice_id.id, 'state': 'running'})
        self.instalment_complete = True
        return {
            'type': 'ir.actions.act_window',
            'name': _('Invoice'),
            'res_model': 'account.move',
            'res_id': invoice_id.id,
            'view_mode': 'form',
            'target': 'current',
        }


class InsuranceEMI(models.Model):
    """Insurance EMI"""
    _name = 'insurance.emi'
    _description = __doc__
    _rec_name = 'name'

    name = fields.Char(string="Name", required=True, translate=True)
    installment_date = fields.Date(string="Installment Date")
    installment_amount = fields.Monetary(string="Installment Amount")
    premium_type = fields.Selection(related="insurance_information_id.premium_type", string="Premium Type")
    company_id = fields.Many2one('res.company', default=lambda self: self.env.company)
    currency_id = fields.Many2one('res.currency', string='Currency', related="company_id.currency_id")
    insurance_information_id = fields.Many2one('insurance.information')
    invoice_id = fields.Many2one('account.move')
    payment_state = fields.Selection(related="invoice_id.payment_state", string="Invoice Status")

    def action_insurance_invoice(self):
        insurance_invoice = {
            'product_id': self.env.ref('tk_insurance_management.insurance_invoice').id,
            'name': self.name,
            'quantity': 1,
            'price_unit': self.installment_amount,
        }
        invoice_lines = [(0, 0, insurance_invoice)]
        data = {
            'partner_id': self.insurance_information_id.insured_id.id,
            'move_type': 'out_invoice',
            'invoice_date': fields.Date.today(),
            'invoice_line_ids': invoice_lines,
            'insurance_information_id': self.insurance_information_id.id,
        }
        invoice_id = self.env['account.move'].sudo().create(data)
        invoice_id.action_post()
        self.write({'invoice_id': invoice_id.id})
        return {
            'type': 'ir.actions.act_window',
            'name': _('Invoice'),
            'res_model': 'account.move',
            'res_id': invoice_id.id,
            'view_mode': 'form',
            'target': 'current',
        }
