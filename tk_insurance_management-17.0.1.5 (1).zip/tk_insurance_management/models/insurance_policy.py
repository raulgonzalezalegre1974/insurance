# -*- coding: utf-8 -*-
# Copyright 2022-Today TechKhedut.
# Part of TechKhedut. See LICENSE file for full copyright and licensing details.
from odoo.exceptions import UserError, ValidationError
from odoo import fields, models, api, _


class InsuranceTimePeriod(models.Model):
    """Insurance Time Period"""
    _name = 'insurance.time.period'
    _description = __doc__
    _rec_name = 't_period'

    t_period = fields.Char(string="Policy Time Period", required=True, translate=True)
    duration = fields.Integer(string="Duration (Months)")

    @api.constrains('duration')
    def _check_duration(self):
        for record in self:
            if record.duration <= 0:
                raise ValidationError(_("Please add an insurance time period greater than zero."))


class InsuranceBuyingFor(models.Model):
    """Insurance Buying For"""
    _name = 'insurance.buying.for'
    _description = __doc__
    _rec_name = 'buying_for'

    buying_for = fields.Char(string="Buying For", required=True)
    insurance_category_id = fields.Many2one('insurance.category', string="Policy Category", required=True)


class InsurancePolicy(models.Model):
    """Insurance Policy"""
    _name = 'insurance.policy'
    _description = __doc__
    _rec_name = 'policy_name'

    policy_name = fields.Char(string="Name", required=True)
    policy_number = fields.Char(string="Policy Number", required=True)
    insurance_category_id = fields.Many2one('insurance.category', string="Policy Category", required=True)
    category = fields.Selection(related="insurance_category_id.category", string='Category')
    insurance_sub_category_id = fields.Many2one('insurance.sub.category', string="Sub Category",
                                                domain="[('insurance_category_id', '=', insurance_category_id)]",
                                                required=True)

    insurance_time_period_id = fields.Many2one('insurance.time.period', string="Policy Time Period", required=True)
    duration = fields.Integer(related="insurance_time_period_id.duration", string="Duration (Months)")
    file_name = fields.Char(string="filename", translate=True)
    avatar = fields.Binary(string="Document")
    policy_terms_and_conditions = fields.Text(string="Terms & Conditions", translate=True)

    phone = fields.Char(related='company_id.phone', string="Phone", translate=True)
    street = fields.Char(related="company_id.street", string="Street", translate=True)
    street2 = fields.Char(related="company_id.street2", string="Street 2", translate=True)
    city = fields.Char(related="company_id.city", string="City", translate=True)
    state_id = fields.Many2one(related="company_id.state_id", string="State")
    country_id = fields.Many2one(related="company_id.country_id", string="Country")
    zip = fields.Char(related="company_id.zip", string="Zip")

    policy_amount = fields.Monetary(string="Amount", required=True)
    currency_id = fields.Many2one('res.currency', string='Currency', related="company_id.currency_id")
    company_id = fields.Many2one('res.company', default=lambda self: self.env.company, string="Company", required=True)

    # Life Insurance:
    life_insured_age = fields.Selection(
        [('five_to_twenty', "Between 5 to 20 Years"), ('twenty_to_fifty', "Between 20 to 50 Years"),
         ('fifty_to_seventy', "Between 50 to 70 Years"), ('above_seventy', "Above 70 Years")])
    desired_death_amount = fields.Monetary(string="Death Amount")
    life_deductible_amount = fields.Monetary()
    length_of_coverage_term = fields.Text(string="Length of Coverage Terms", translate=True)
    life_health_history = fields.Text(string="Insured Health History", translate=True)
    occupation_and_hobbies = fields.Text(string="Occupation and Hobbies", translate=True)
    family_medical_history = fields.Text(string="Family Medical History", translate=True)

    # Health Insurance:
    health_insured_age = fields.Selection(
        [('five_to_twenty', "Between 5 to 20 Years"), ('twenty_to_fifty', "Between 20 to 50 Years"),
         ('fifty_to_seventy', "Between 50 to 70 Years"), ('above_seventy', "Above 70 Years")])
    desired_coverage_type = fields.Selection([('individual', "Individual"), ('family', "Family"), ('group', "Group")])
    health_deductible_amount = fields.Monetary()
    out_of_pocket_maximum = fields.Text(string="Out-of-Pocket Maximum", translate=True)
    health_history_of_insured = fields.Text(translate=True)
    drug_coverage = fields.Text(string="Prescription Drug Coverage", translate=True)
    healthcare_provider_network = fields.Text(string="Preferred Healthcare Provider Network", translate=True)

    # Property Insurance:
    construct_year = fields.Integer(string="Construct Year")
    property_value = fields.Monetary()
    property_damage_coverage = fields.Monetary(string="Damage Coverage")
    property_coverage_limits = fields.Text(string="Property Coverage Limits", translate=True)
    construction_type_and_materials = fields.Text(string="Construction Type and Materials", translate=True)
    special_features_of_the_property = fields.Text(string="Special Features of the Property", translate=True)
    personal_property_inventory = fields.Text(string="Personal Property Inventory", translate=True)

    # Liability Insurance:
    type_of_liability_risk = fields.Selection(
        [('auto', "Auto"), ('homeowner', "HomeOwner's"), ('business', "Business")], string="Liability Risk")
    liability_coverage_type = fields.Selection(
        [('general_liability', "General Liability"), ('professional_liability', "Professional Liability")])
    desired_coverage_limits = fields.Text(string="Desired Coverage Limits", translate=True)
    business_type_and_operations = fields.Text(translate=True)

    # Disability Insurance:
    income = fields.Monetary(string="Income")
    disability_deductible_amount = fields.Monetary()
    length_coverage_disability_period = fields.Text(string="Length of Coverage Period", translate=True)
    disability_health_history = fields.Text(translate=True)
    occupation_and_hobbies = fields.Text(string="Occupation and Hobbies", translate=True)

    # Travel Insurance:
    types_of_coverage = fields.Selection(
        [('trip_cancellation', "Trip Cancellation"), ('medical_emergency', "Medical Emergency"),
         ('lost_luggage', "Lost Luggage")], string="Type of Coverage")
    trip_coverage_amount = fields.Monetary(string="Coverage Amount")
    traveler_health_history = fields.Text(string="Traveler Health History", translate=True)

    # Pet Insurance:
    pet_desired_coverage_type = fields.Selection(
        [('accident', "Accident"), ('illness', "Illness"), ('comprehensive', "Comprehensive")], string="Coverage Type ")
    exclusions = fields.Selection(
        [('pre_existing_conditions', "Pre-Existing Conditions"), ('certain_breeds', "Certain Breeds")],
        string="Exclusions")
    accident_coverage = fields.Monetary(string="Accident Coverage Amount")
    illness_coverage = fields.Monetary(string="Illness Coverage Amount")
    pet_coverage_limits = fields.Text(string="Coverage Limits", translate=True)

    # Business Insurance:
    business_desired_coverage_type = fields.Selection(
        [('property_damage', "Property Damage"), ('liability', "Liability"), ('workers', "Workers Compensation")])
    business_property_value = fields.Monetary()
    business_type_operation = fields.Text(translate=True)
    business_coverage_limits = fields.Text(string="Business Coverage Limits", translate=True)
    industry_specific_risks = fields.Text(string=" Industry-Specific Risks", translate=True)

    # Vehicle Insurance:
    coverage_type = fields.Selection(
        [('liability', "Liability"), ('collision', "Collision"), ('comprehensive', "Comprehensive")])
    driving_history = fields.Text(string="Driving History of the Insured", translate=True)
    limitation_as_to_use = fields.Text(string="Limitation as to Use", translate=True)
    limits_of_liability = fields.Text(string="Limits of Liability", translate=True)
    deductibles_under_section = fields.Text(string="Deductibles under Section", translate=True)
    special_conditions = fields.Text(string="Special Conditions", translate=True)
    vehicle_insurance_image_ids = fields.One2many('vehicle.insurance.image', 'insurance_policy_id', string="Images")

    @api.constrains('policy_amount')
    def _check_policy_amount(self):
        for record in self:
            if record.policy_amount == 0:
                raise ValidationError(_("Please policy amount can not be zero"))

    @api.onchange('insurance_category_id')
    def get_insurance_policy(self):
        for rec in self:
            if rec.insurance_category_id:
                # Life Insurance:
                rec.length_of_coverage_term = rec.insurance_category_id.length_of_coverage_term
                rec.life_health_history = rec.insurance_category_id.life_health_history
                rec.occupation_and_hobbies = rec.insurance_category_id.occupation_and_hobbies
                rec.family_medical_history = rec.insurance_category_id.family_medical_history
                # Health Insurance:
                rec.out_of_pocket_maximum = rec.insurance_category_id.out_of_pocket_maximum
                rec.health_history_of_insured = rec.insurance_category_id.health_history_of_insured
                rec.drug_coverage = rec.insurance_category_id.drug_coverage
                rec.healthcare_provider_network = rec.insurance_category_id.healthcare_provider_network
                # Property Insurance:
                rec.property_coverage_limits = rec.insurance_category_id.property_coverage_limits
                rec.construction_type_and_materials = rec.insurance_category_id.construction_type_and_materials
                rec.special_features_of_the_property = rec.insurance_category_id.special_features_of_the_property
                rec.personal_property_inventory = rec.insurance_category_id.personal_property_inventory
                # Liability Insurance:
                rec.desired_coverage_limits = rec.insurance_category_id.desired_coverage_limits
                rec.business_type_and_operations = rec.insurance_category_id.business_type_and_operations
                # Disability Insurance:
                rec.length_coverage_disability_period = rec.insurance_category_id.length_coverage_disability_period
                rec.disability_health_history = rec.insurance_category_id.disability_health_history
                rec.occupation_and_hobbies = rec.insurance_category_id.occupation_and_hobbies
                # Travel Insurance:
                rec.traveler_health_history = rec.insurance_category_id.traveler_health_history
                # Pet Insurance:
                rec.pet_coverage_limits = rec.insurance_category_id.pet_coverage_limits
                # Business Insurance:
                rec.business_type_operation = rec.insurance_category_id.business_type_operation
                rec.business_coverage_limits = rec.insurance_category_id.business_coverage_limits
                rec.industry_specific_risks = rec.insurance_category_id.industry_specific_risks
                # Vehicle Insurance:
                rec.driving_history = rec.insurance_category_id.driving_history
                rec.limitation_as_to_use = rec.insurance_category_id.limitation_as_to_use
                rec.limits_of_liability = rec.insurance_category_id.limits_of_liability
                rec.deductibles_under_section = rec.insurance_category_id.deductibles_under_section
                rec.special_conditions = rec.insurance_category_id.special_conditions
