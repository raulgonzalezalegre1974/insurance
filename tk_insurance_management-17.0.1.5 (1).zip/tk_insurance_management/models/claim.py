# -*- coding: utf-8 -*-
# Copyright 2022-Today TechKhedut.
# Part of TechKhedut. See LICENSE file for full copyright and licensing details.
from odoo.exceptions import ValidationError
from odoo.exceptions import UserError
from odoo import api, fields, models, _


class ClaimInformation(models.Model):
    """Claim Information"""
    _name = "claim.information"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = __doc__
    _rec_name = 'claim_number'

    claim_number = fields.Char(string='Claim', required=True, readonly=True, default=lambda self: _('New'), copy=False)
    insurance_id = fields.Many2one('insurance.information', string="Insurance", required=True)
    insured_id = fields.Many2one('res.partner', string='Insured')
    phone = fields.Char(string="Phone")
    dob = fields.Date()
    age = fields.Char(string="Age", compute="get_insured_age_count", translate=True)
    insurance_nominee_id = fields.Many2one('insurance.nominee', string="Nominee")
    insurance_nominee_relation_id = fields.Many2one('insurance.nominee.relation', string="Your Nominee is Your")
    nominee_dob = fields.Date()
    insurance_policy_id = fields.Many2one('insurance.policy', string='Insurance Policy',
                                          domain="[('insurance_sub_category_id', '=', insurance_sub_category_id)]",
                                          required=True)
    insurance_category_id = fields.Many2one('insurance.category', string="Policy Category", required=True)
    insurance_sub_category_id = fields.Many2one('insurance.sub.category', string="Sub Category",
                                                domain="[('insurance_category_id', '=', insurance_category_id)]",
                                                required=True)
    insurance_time_period = fields.Char(string="Policy Time Period", translate=True)
    agent_id = fields.Many2one('res.partner', string='Agent', domain=[('is_agent', '=', True)])

    policy_amount = fields.Monetary(string="Policy Amount")
    amount_paid = fields.Monetary(string="Claim Amount")
    due_amount = fields.Monetary(string="Remaining Amount")

    company_id = fields.Many2one('res.company', default=lambda self: self.env.company, string="Company")
    currency_id = fields.Many2one('res.currency', string='Currency', related="company_id.currency_id")
    claim_date = fields.Date(string='Date', required=True)
    policy_terms_and_conditions = fields.Text(string="Terms & Conditions", translate=True)

    invoice_id = fields.Many2one('account.move', string="Claim Bill")
    payment_status = fields.Selection(related='invoice_id.payment_state', string="Payment Status")

    claim_documents_ids = fields.One2many('claim.documents', 'claim_information_id', string="Claim Documents")
    claim_reasons_ids = fields.Many2many('claim.reasons', string="Claim Reasons")

    state = fields.Selection([('draft', "New"), ('submit', "Submit"), ('approved', "Approved"),
                              ('not_approved', "Not Approved")], default='draft')

    # unsued
    your_nominee_is_your = fields.Selection([('grand_daughter', "Grand Daughter"), ('grand_mother', "Grand Mother"),
                                             ('niece', "Niece"), ('sister', "Sister"), ('aunt', "Aunt"),
                                             ('daughter', "Daughter"), ('mother', "Mother")],
                                            string=" Your Nominee is Your")
    maturity_of_the_policy = fields.Boolean(string="Maturity of the Policy")
    surrender_of_the_policy = fields.Boolean(string="Surrender of the Policy")
    discounted_value_in_policy = fields.Boolean(string="Discounted Value in Policy")
    death_of_the_insured = fields.Boolean(string="Death of the Insured")
    paid_up_of_lapsed_policy = fields.Boolean(string="Paid up of Lapsed Policy")
    other = fields.Boolean(string="Other")
    furnish_date_of_death = fields.Date(string="Date of Death")

    def draft_to_submit(self):
        self.state = 'submit'

    def submit_to_approved(self):
        if not self.claim_documents_ids:
            message = self._create_warning_notification(
                "Ensure claim documents are submitted promptly to expedite processing")
            return message
        documents_verified = all(rec.state == 'verified' for rec in self.claim_documents_ids)
        if not documents_verified:
            message = self._create_warning_notification("Please complete claim documents")
            return message
        if not self.amount_paid:
            message = self._create_warning_notification("Please add the claim amount")
            return message
        self.ensure_one()
        self.state = 'approved'
        template_id = self.env.ref("tk_insurance_management.insurance_policy_has_been_approved_mail_template").sudo()
        ctx = {
            'default_model': 'claim.information',
            'default_res_ids': self.ids,
            'default_partner_ids': [self.insured_id.id],
            'default_use_template': bool(template_id),
            'default_template_id': template_id.id,
            'default_composition_mode': 'comment',
            'default_email_from': self.env.company.email,
            'default_reply_to': self.env.company.email,
            'custom_layout': False,
            'force_email': True,
        }
        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'views': [(False, 'form')],
            'view_id': False,
            'target': 'new',
            'context': ctx,
        }

    def _create_warning_notification(self, message):
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'type': 'warning',
                'message': message,
                'sticky': False,
            }
        }

    def approved_to_not_approved(self):
        self.state = 'not_approved'

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('claim_number', _('New')) == _('New'):
                vals['claim_number'] = self.env['ir.sequence'].next_by_code('claim.information') or _('New')
        res = super(ClaimInformation, self).create(vals_list)
        return res

    @api.onchange('insurance_nominee_id')
    def insurance_nominee_details(self):
        for rec in self:
            if rec.insurance_nominee_id:
                rec.insurance_nominee_relation_id = rec.insurance_nominee_id.insurance_nominee_relation_id.id
                rec.nominee_dob = rec.insurance_nominee_id.nominee_dob
            else:
                rec.insurance_nominee_relation_id = False
                rec.nominee_dob = False

    @api.constrains('claim_date', 'insurance_id')
    def _check_claim_date(self):
        for rec in self:
            if rec.claim_date and rec.insurance_id:
                if rec.claim_date < rec.insurance_id.issue_date or rec.claim_date > rec.insurance_id.expiry_date:
                    raise ValidationError(_("Claim Date must be within the insurance coverage period!"))

    @api.constrains('furnish_date_of_death')
    def _check_furnish_date_of_death(self):
        today = fields.Date.today()
        for record in self:
            if record.furnish_date_of_death:
                if record.furnish_date_of_death > today:
                    raise ValidationError(_("Date of death cannot exceed current date"))

    @api.constrains('amount_paid')
    def _check_amount_paid(self):
        for record in self:
            if record.amount_paid > record.policy_amount or record.amount_paid > record.due_amount:
                raise ValidationError(_(
                    "Claim amount exceeds policy limit. Verify it stays within the policy coverage"))

    @api.depends('dob')
    def get_insured_age_count(self):
        today = fields.Date.today()
        for rec in self:
            if rec.dob:
                if rec.dob > today:
                    raise ValidationError("DOB should be earlier than today's date.")
                age = today.year - rec.dob.year - ((today.month, today.day) < (rec.dob.month, rec.dob.day))
                rec.age = str(max(age, 0)) + ' Years'
            else:
                rec.age = str(0) + ' Years'

    @api.onchange('insurance_id')
    def get_insurance_details(self):
        for rec in self:
            if rec.insurance_id:
                rec.insured_id = rec.insurance_id.insured_id
                rec.dob = rec.insurance_id.dob
                rec.phone = rec.insurance_id.insured_id.phone
                rec.insurance_nominee_id = rec.insurance_id.insurance_nominee_id.id
                rec.insurance_nominee_relation_id = rec.insurance_id.insurance_nominee_relation_id.id
                rec.nominee_dob = rec.insurance_id.nominee_dob
                rec.insurance_policy_id = rec.insurance_id.insurance_policy_id.id
                rec.insurance_time_period = rec.insurance_id.insurance_time_period
                rec.insurance_category_id = rec.insurance_id.insurance_category_id.id
                rec.insurance_sub_category_id = rec.insurance_id.insurance_sub_category_id.id
                rec.agent_id = rec.insurance_id.agent_id.id
                rec.insurance_time_period = rec.insurance_id.insurance_time_period
                rec.policy_amount = rec.insurance_id.policy_amount
            else:
                rec.insured_id = False
                rec.dob = False
                rec.phone = False
                rec.insurance_nominee_id = False
                rec.insurance_nominee_relation_id = False
                rec.nominee_dob = False
                rec.insurance_policy_id = False
                rec.insurance_time_period = False
                rec.insurance_category_id = False
                rec.insurance_sub_category_id = False
                rec.agent_id = False
                rec.insurance_time_period = False
                rec.policy_amount = False

    def action_claim_settlement_amount(self):
        for record in self:
            if record.amount_paid == 0:
                message = {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'type': 'warning',
                        'title': (_('Please note')),
                        'message': "Claim amount cannot be zero",
                        'sticky': False,
                    }
                }
                return message
            claim_record = {
                'name': 'Claim Settlement Amount',
                'quantity': 1,
                'price_unit': record.amount_paid,
                'tax_ids': False,
            }
            invoice_lines = [(0, 0, claim_record)]
            data = {
                'partner_id': record.agent_id.id,
                'move_type': 'in_invoice',
                'invoice_date': fields.Datetime.now(),
                'invoice_line_ids': invoice_lines,
                'claim_information_id': record.id
            }
            invoice_id = self.env['account.move'].sudo().create(data)
            invoice_id.action_post()
            record.invoice_id = invoice_id.id
            return {
                'type': 'ir.actions.act_window',
                'name': 'Claim Bills',
                'res_model': 'account.move',
                'res_id': invoice_id.id,
                'view_mode': 'form',
                'target': 'current'
            }
