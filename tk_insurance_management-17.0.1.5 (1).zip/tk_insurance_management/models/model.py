# -*- coding: utf-8 -*-
# Copyright 2022-Today TechKhedut.
# Part of TechKhedut. See LICENSE file for full copyright and licensing details.
from odoo import models, fields, api, _


class AccountMove(models.Model):
    """Account Move"""
    _inherit = 'account.move'
    _description = __doc__

    insurance_information_id = fields.Many2one('insurance.information', string="Insurance")
    claim_information_id = fields.Many2one('claim.information', string="Claim")


class ResPartner(models.Model):
    """Res Partner """
    _inherit = 'res.partner'
    _description = __doc__

    is_agent = fields.Boolean(string="Agent")
    insurance_information_ids = fields.One2many('insurance.information', 'agent_id', string="Insurance")
    total_agent_bill = fields.Monetary(string="Total", compute="_compute_total_agent_bill")

    @api.depends('insurance_information_ids.agent_bill_id.amount_total')
    def _compute_total_agent_bill(self):
        for rec in self:
            rec.total_agent_bill = sum(bill.agent_bill_id.amount_total for bill in rec.insurance_information_ids)

    def action_bill_view(self):
        return {
            'type': 'ir.actions.act_window',
            'name': _('Agent Commission Bills'),
            'res_model': 'account.move',
            'view_mode': 'tree,form',
            'target': 'current',
            'domain': [
                ('insurance_information_id', 'in', self.insurance_information_ids.ids),
                ('partner_id', '=', self.id),
            ],
            'context': {
                'default_partner_id': self.id,
                'create': False,
            },
        }
